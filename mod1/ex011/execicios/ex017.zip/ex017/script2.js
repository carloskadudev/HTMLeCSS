function verificar(){
    let data = new Date()
    let ano = data.getFullYear()
    let fano = document.getElementById('txtano')
    let res = document.querySelector('div#res')
    if (fano.value.length == 0 || fano.value > ano) {
      window.alert('[ERROR]verifique os dados e tente novamente!')
    } else {
        let fsex = document.getElementsByName('radsex')
        let idade = ano - Number(fano.value)
        let gênero = ''
        let img = document.createElement('img')
        img.setAttribute('id','foto')
        if (fsex[0].checked) {
           gênero = 'homem'
           if (idade >=0 && idade < 10 ) {
            //Criança
             img.setAttribute('src','bebe-h.jpg')
           } else if (idade < 20) {
            //Jovem
            img.setAttribute('src','jovem-h.jpg')
           } else if (idade < 50) {
            //Adulto
            img.setAttribute('src','adulto-h.jpg')
           } else {
            //Idoso
            img.setAttribute('src','idoso.jpg')
           }
         
        } else if (fsex[1].checked) {
           gênero = 'mulher'
           if (idade >=0 && idade < 10 ) {
            //Criança
             img.setAttribute('src','bebe-m.jpg')
           } else if (idade < 20) {
            //Jovem
            img.setAttribute('src','jovem-m.jpg')
           } else if (idade < 50) {
            //Adulto
             img.setAttribute('src','adulto-m.jpg')
           } else {
            //Idosa
            img.setAttribute('src','idosa.jpg')
           }

        }
        res.style.textAling = 'center'
        res.innerHTML = `Detectamos ${gênero} com ${idade} anos.`
        res.appendChild(img)
    }

}